
<a href="https://wa.me/123" target="_blank" class="btn btn-success" style="position: fixed;
right: -20px;
 top: 50%;
 transform: rotate(-90deg);
 z-index: 100;">
  whatsapp
</a>
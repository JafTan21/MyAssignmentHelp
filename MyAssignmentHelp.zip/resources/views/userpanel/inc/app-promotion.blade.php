<div class="appPromotion">
    <div class="text-center">
        <h2>Order on the go!</h2>
        <p class="sub-text">Say hello to our new app</p>
        <div class="d-flex">
            <div class="appstore" id="downloadappleapp">
                <a href="#" target="_blank">
                    <img width="168" height="50" src="https://mahcmsresources.s3.amazonaws.com/iosapp-1617611781.png"
                        data-src="https://mahcmsresources.s3.amazonaws.com/iosapp-1617611781.png" alt="APP in IOS"
                        class="lazy loaded" data-was-processed="true">
                </a>
            </div>
            <div class="appstore" id="downloadandriodapp">
                <a href="#" target="_blank">
                    <img width="168" height="50"
                        src="https://mahcmsresources.s3.amazonaws.com/playstoreapp-1617611781.png"
                        data-src="https://mahcmsresources.s3.amazonaws.com/playstoreapp-1617611781.png"
                        alt="APP in PlayStore" class="lazy loaded" data-was-processed="true">
                </a>
            </div>
        </div>
    </div>
</div>
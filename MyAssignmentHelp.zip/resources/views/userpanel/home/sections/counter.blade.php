<section style="padding:80px 0; background:#dcd4d073;">
    <div class="container">
        <div class="row text-center">
            <div class="col">
                <div class="counter">
                    <i class="fas fa-clipboard-list fa-2x"></i>
                    <h2 class="timer count-title count-number" data-to="100" data-speed="1500"></h2>
                    <p class="count-text ">DELIVERED ORDERS</p>
                </div>
            </div>
            <div class="col">
                <div class="counter">
                    <i class="fas fa-chalkboard-teacher fa-2x"></i>
                    <h2 class="timer count-title count-number" data-to="1700" data-speed="1500"></h2>
                    <p class="count-text ">EXPERTS</p>
                </div>
            </div>
            <div class="col">
                <div class="counter">
                    <i class="fas fa-star-half-alt fa-2x"></i>
                    <h2 class="timer count-title count-number" data-to="11900" data-speed="1500"></h2>
                    <p class="count-text ">CLIENT RATING</p>
                </div>
            </div>
        </div>
    </div>
</section>